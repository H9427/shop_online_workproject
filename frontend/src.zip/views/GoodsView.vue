<template>
  <Navbar />
  <GoodsCategory />
</template>