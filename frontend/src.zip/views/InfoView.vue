<template>
  <Navbar />
  <Info />
</template>
