<template>
  <Navbar />
  <ShoppingCart />
</template>
