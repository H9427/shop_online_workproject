<template>
  <Navbar />
  <GoodsDetail />
</template>