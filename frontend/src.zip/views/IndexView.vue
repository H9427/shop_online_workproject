<template>
    <Navbar />
    <HomeView />
    <Footer />
</template>

<!-- <script>
import HomeView from "../components/HomeView.vue";

export default {
  components: {
    HomeView,
  },
  data() {
    return {
      currentComponent: "HomeView", // 初始主页面
    };
  },
};
</script>

<style scoped></style> -->
